<?php

namespace App\Controllers;

use App\Models\CommentModels;
use App\Models\ProjectModels;
use App\Models\UserModels;

class Project extends BaseController
{

    protected $userModel;
    protected $projectModel;
    protected $commentModel;
    public function __construct()
    {
        $this->userModel    = new UserModels();
        $this->projectModel = new ProjectModels();
        $this->commentModel = new CommentModels();
        date_default_timezone_set('Asia/Jakarta');
    }

    public function test()
    {
        // $this->projectModel->insertFile("1212", 1);
        $this->projectModel->deleteFiles(14);
        return view('pages/test');
    }

    public function images()
    {
        $image = $_POST['image'];
        $image_array_1 = explode(";", $image);
        $image_array_2 = explode(",", $image_array_1[1]);
        $data = base64_decode($image_array_2[1]);

        $image_name = 'upload/' . time() . '.png';

        file_put_contents($image_name, $data);
        return json_encode(array(
            'msg'   => 200
        ));
    }

    public function index()
    {
        if ($this->session->get('project')) {
            return redirect()->to(base_url() . '/project/home');
        } else {
            return view('pages/login_view');
        }
    }

    public function logout()
    {
        $this->session->destroy();
        return redirect()->to(base_url() . '/');
    }

    public function check_login()
    {
        if ($this->request->isAJAX()) {

            $username = $_POST['username'];
            $password = $_POST['password'];

            // checkusername
            $checkUser = $this->userModel->checkUsername($username);
            if ($checkUser != null) {
                $checkPass = $this->userModel->checkPassword($username, $password);
                if ($checkPass != null) {

                    // SET SESSION

                    $session = session();
                    if ($checkPass['status'] == 'admin') {
                        $loginData = [
                            'project'     => true,
                            'username'  => $checkPass['username'],
                            'full_name' => $checkPass['full_name'],
                            'id'        => $checkPass['id'],
                            'gender'    => $checkPass['gender'],
                            'role'      => 'admin',
                            'division'  => $checkPass['division']
                        ];
                    } else {
                        $loginData = [
                            'project' => true,
                            'username'  => $checkPass['username'],
                            'full_name' => $checkPass['full_name'],
                            'id'        => $checkPass['id'],
                            'gender'    => $checkPass['gender'],
                            'role'      => 'member',
                            'division'  => $checkPass['division']
                        ];
                    }

                    $session->set($loginData);

                    $result = array(
                        'status' => 200
                    );
                } else {
                    $result = array(
                        'status' => 402
                    );
                }
            } else {
                $result = array(
                    'status' => 404
                );
            }

            return json_encode($result);
        }
    }


    // project
    public function home()
    {


        if ($this->session->get('role') == 'member') {
            $id = $this->session->get('id');
            $progress = $this->projectModel->getProgress($id);
            $complete = $this->projectModel->getComplete($id);
            $all      = $this->projectModel->getAllProject($id);
        } else {
            $id = $this->session->get('id');
            $progress = $this->projectModel->getProgressAdmin();
            $complete = $this->projectModel->getCompleteAdmin();
            $all      = $this->projectModel->getAllProjectAdmin();
        }


        if ($complete <= 0) {
            $progress_percent  = 0;
        } else {
            $progress_percent  = intval($complete) / intval($all) * 100;
        }

        $userData          = $this->userModel->getWhere(['id' => $id])->getRowArray();

        $data = [
            'active'     => 'dashboard',
            'progress'   => $progress,
            'percentage' => $progress_percent,
            'complete'   => $complete,
            'user'       => $userData
        ];

        return view('pages/home_view', $data);
    }

    public function getGrafik()
    {
        $grafik = [];
        if ($this->session->get('role') == 'member') {
            $id = $this->session->get('id');
            for ($i = 1; $i <= 12; $i++) {
                $getComplete = $this->projectModel->getProjectMonthly($i, $id);
                array_push($grafik, $getComplete);
            }
        } else {
            for ($i = 1; $i <= 12; $i++) {
                $getComplete = $this->projectModel->getProjectMonthlyAdmin($i);
                array_push($grafik, $getComplete);
            }
        }
        return json_encode(array(
            'grafik'    => $grafik
        ));
    }


    public function projectMenu()
    {

        $id = $this->session->get('id');
        if ($this->session->get('role') == 'member') {
            $progress = $this->projectModel->getProgress($id);
        } else {
            $progress = $this->projectModel->getProgressAdmin();
        }
        $userData          = $this->userModel->getWhere(['id' => $id])->getRowArray();
        $divisi            = $this->userModel->getDistinctDivision();
        $company           = $this->userModel->getDistinctCompany();

        $data = [
            'active'    => 'project',
            'progress'  => $progress,
            'user'      => $userData,
            'divisi'    => $divisi,
            'company'   => $company
        ];
        return view('pages/project_view', $data);
    }







    // READ PROJECT

    public function getListProject()
    {
        $id         = $this->session->get('id');
        $role       = $this->session->get('role');
        $limit      = $_POST['limit'];
        $sort       = $_POST['sort'];
        $division   = $_POST['divisi'];
        $company    = $_POST['company'];

        $listServis = $this->projectModel->getListProject($limit, $sort, $division, $company, $id, $role);

        return json_encode(array(
            'project' => $listServis
        ));
    }

    public function getDetailProject()
    {
        if ($this->request->isAJAX()) {
            $id        = $_POST['id'];
            $listFiles = $this->projectModel->listFiles($id);
            $data      = $this->projectModel->detailProject($id);
            $comment   = $this->commentModel->getComment($id);


            $id_user = $this->session->get('id');
            return json_encode(array(
                'data'      => $data,
                'comment'   => $comment,
                'user_id'   => $id_user,
                'list_file' => $listFiles
            ));
        }
    }


    // CREATE AND UPDATE

    public function addProject()
    {
        $project          = $_POST['project'];
        $due_date         = $_POST['waktu'];
        $progress         = $_POST['progress'];
        $estimasi_biaya   = $_POST['estimasi_biaya'];
        $estimasi_cpus    = $_POST['estimasi_cpus'];
        $estimasi_revenue = $_POST['estimasi_revenue'];
        $biaya_aktual     = $_POST['biaya_aktual'];
        $cpus_aktual      = $_POST['cpus_aktual'];
        $revenue_aktual   = $_POST['revenue_aktual'];

        $jenis_project    = $_POST['jenis'];
        $priority         = $_POST['priority'];
        $id_user          = $this->session->get('id');

        $data = [
            'project'               => $project,
            'progress'              => $progress,
            'due_date'              => $due_date,
            'estimation_cpus'       => $estimasi_cpus,
            'estimation_cost'       => $estimasi_biaya,
            'estimation_revenue'    => $estimasi_revenue,
            'actual_cpus'           => $cpus_aktual,
            'actual_cost'           => $biaya_aktual,
            'actual_revenue'        => $revenue_aktual,
            'id_user'               => $id_user,
            'project_type'          => strtoupper($jenis_project),
            'priority'              => strtoupper($priority)
        ];


        $save = $this->projectModel->insert($data);
        if ($save) {
            return json_encode(array(
                'data'  => $data
            ));
        }
    }

    public function updateProject()
    {
        if ($this->request->isAJAX()) {


            $id_project       = $_POST['id_project'];
            $project          = $_POST['detailJudul'];
            $desc             = $_POST['detailDesc'];
            $due_date         = $_POST['detailWaktu'];
            $progress         = $_POST['detailProgress'];
            $priority         = $_POST['detailPriority'];
            $estimasi_biaya   = $_POST['detailEstimasiBiaya'];
            $estimasi_cpus    = $_POST['detailEstimasiCPUS'];
            $estimasi_revenue = $_POST['detailEstimasiRevenue'];
            $biaya_aktual     = $_POST['detailBiayaAktual'];
            $cpus_aktual      = $_POST['detailAktualCPUS'];
            $revenue_aktual   = $_POST['detailAktualRevenue'];

            $data = [
                'id'                    => $id_project,
                'project'               => $project,
                'progress'              => $progress,
                'description'           => $desc,
                'due_date'              => $due_date,
                'estimation_cpus'       => str_replace(".", "", strval($estimasi_cpus)),
                'estimation_cost'       => str_replace(".", "", strval($estimasi_biaya)),
                'estimation_revenue'    => str_replace(".", "", strval($estimasi_revenue)),
                'actual_cpus'           => str_replace(".", "", strval($cpus_aktual)),
                'actual_cost'           => str_replace(".", "", strval($biaya_aktual)),
                'actual_revenue'        => str_replace(".", "", strval($revenue_aktual)),
                'priority'              => $priority
            ];

            if ($_FILES['file_data']['name'] == "") {
                $update = $this->projectModel->save($data);
                if ($update) {
                    return json_encode(array(
                        'data'  => $data
                    ));
                }
            } else {
                $file             = $this->request->getFile('file_data');
                $file_name        = $file->getName();
                $file->move('files/', $file_name);

                $update = $this->projectModel->save($data);
                if ($update) {
                    $this->projectModel->insertFile(strval($file_name), strval($id_project));
                    return json_encode(array(
                        'data'  => $data
                    ));
                }
            }
        }
    }


    // Delete Project
    public function deleteProject()
    {
        if ($this->request->isAJAX()) {
            $id     = $_POST['id'];

            $checkFiles = $this->projectModel->listFiles($id);
            if ($checkFiles != null) {
                for ($i = 0; $i < sizeof($checkFiles); $i++) {
                    unlink('files/' . $checkFiles[$i]->file_name);
                }
                $this->projectModel->deleteFiles($id);
            }
            $this->projectModel->delete(['id' => $id]);
            $this->commentModel->delete(['id_project' => $id]);
            $this->commentModel->where('id_project', $id)->delete();


            return json_encode(array(
                'message'   => 200
            ));
        }
    }


    // Images
    public function save_image()
    {
        $data = $_POST["image"];

        $image_array_1 = explode(";", $data);

        $image_array_2 = explode(",", $image_array_1[1]);

        $data = base64_decode($image_array_2[1]);

        $imageName = time() . '.png';

        file_put_contents('img/' . $imageName, $data);
        // delete old image
        $id       = $this->session->get('id');
        $userData = $this->userModel->getWhere(['id' => $id])->getRowArray();

        if ($userData != 'default-image.png') {
            $fileImage = 'img/' . $userData['image'];
            if (file_exists($fileImage)) {
                unlink($fileImage);
            }
        }

        $data = [
            'id'    => $this->session->get('id'),
            'image' => $imageName
        ];
        $this->userModel->save($data);
    }



    // Comment
    public function sendComment()
    {
        if ($this->request->isAJAX()) {
            $id_user    = $this->session->get('id');
            $id_project = $_POST['id_project'];
            $comment    = $_POST['input'];

            $data = [
                'comment'       => $comment,
                'id_user'       => $id_user,
                'id_project'    => $id_project
            ];

            $comment     = $this->commentModel->insert($data);
            if ($comment) {
                return json_encode(array(
                    'status'    => 200
                ));
            }
        }
    }


    // Member
    public function member()
    {
        $data = [
            'active' => 'member'
        ];

        return view('pages/member_view', $data);
    }

    public function getMember()
    {
        if ($this->request->isAJAX()) {
            $user = $this->userModel->orderBy('division', 'ASC')->findAll();

            return json_encode(array(
                'user'  => $user
            ));
        }
    }

    public function addMember()
    {
        if ($this->request->isAJAX()) {

            $username  = $_POST['username'];
            $password  = $_POST['password'];
            $full_name = $_POST['full_name'];
            $division  = $_POST['division'];
            $gender    = $_POST['gender'];
            $company   = $_POST['company'];
            $status    = $_POST['status'];
            $id        = $_POST['id_member'];

            if ($id == "-") {
                $data = [
                    'username'  => $username,
                    'password'  => $password,
                    'full_name' => $full_name,
                    'division'  => $division,
                    'gender'    => $gender,
                    'company'   => $company,
                    'image'     => 'default-image.png',
                    'status'    => $status
                ];

                $insert = $this->userModel->insert($data);
                if ($insert) {
                    return json_encode(array(
                        'status' => 200
                    ));
                } else {
                    return json_encode(array(
                        'status' => 402
                    ));
                }
            } else {
                $data = [
                    'id'        => $id,
                    'username'  => $username,
                    'password'  => $password,
                    'full_name' => $full_name,
                    'division'  => $division,
                    'gender'    => $gender,
                    'company'   => $company,
                    'status'    => $status
                ];

                $save = $this->userModel->save($data);
                if ($save) {
                    return json_encode(array(
                        'status' => 200
                    ));
                } else {
                    return json_encode(array(
                        'status' => 402
                    ));
                }
            }
        }
    }

    public function deleteMember()
    {
        if ($this->request->isAJAX()) {

            $id = $_POST['id'];

            if ($this->session->get('id') != $id) {
                $deleteProject = $this->projectModel->where('id_user', $id)->delete();
                if ($deleteProject) {
                    $deleteMember = $this->userModel->where('id', $id)->delete();
                    if ($deleteMember) {
                        return json_encode(array(
                            'status'    => 200
                        ));
                    }
                }
            } else {
                return json_encode(array(
                    'status'    => 402
                ));
            }
        }
    }

    public function detailMember()
    {
        if ($this->request->isAJAX()) {
            $id   = $_POST['id'];
            $user = $this->userModel->getWhere(['id' => $id])->getRowArray();

            return json_encode(array(
                'user' => $user
            ));
        }
    }

    public function updateUser()
    {
        $username  = $_POST['username'];
        $password  = $_POST['password'];
        $full_name = $_POST['full_name'];
        $division  = $_POST['division'];
        $gender    = $_POST['gender'];
        $id        = $_POST['id_member'];

        $data = [
            'id'        => $id,
            'username'  => $username,
            'password'  => $password,
            'full_name' => $full_name,
            'division'  => $division,
            'gender'    => $gender
        ];

        $update    = $this->userModel->save($data);
        $user      = $this->userModel->getWhere(['id' => $id])->getRowArray();


        $session = session();
        if ($user['status'] == 'admin') {
            $loginData = [
                'project'     => true,
                'username'  => $user['username'],
                'full_name' => $user['full_name'],
                'id'        => $user['id'],
                'gender'    => $user['gender'],
                'role'      => 'admin',
                'division'  => $user['division']
            ];
        } else {
            $loginData = [
                'project' => true,
                'username'  => $user['username'],
                'full_name' => $user['full_name'],
                'id'        => $user['id'],
                'gender'    => $user['gender'],
                'role'      => 'member',
                'division'  => $user['division']
            ];
        }

        $session->set($loginData);

        if ($update) {
            return json_encode(array(
                'status'    => 200
            ));
        }
    }
}
