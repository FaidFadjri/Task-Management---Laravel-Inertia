<?php

namespace App\Models;

use CodeIgniter\Model;

class ProjectModels extends Model
{
    protected $table      = 'tb_project';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'project', 'description', 'progress', 'due_date', 'estimation_cpus', 'estimation_cost', 'estimation_revenue', 'actual_cpus', 'actual_cost', 'actual_revenue', 'id_user', 'created_at', 'updated_at', 'project_type', 'priority'
    ];
    protected $useTimestamps = true;

    public function getAllProject($id)
    {
        return $this->query("SELECT COUNT(id) as result FROM tb_project WHERE id_user = $id")->getResult()[0]->result;
    }

    public function getProgress($id)
    {
        return $this->query("SELECT COUNT(id) as result FROM tb_project WHERE id_user = $id AND progress = 'WORKING ON IT'")->getResult()[0]->result;
    }

    public function getComplete($id)
    {
        return $this->query("SELECT COUNT(id) as result FROM tb_project WHERE id_user = $id AND progress = 'COMPLETE'")->getResult()[0]->result;
    }


    public function getProjectMonthly($month, $id)
    {
        $startDate = strval(date('Y-' . $month . '-01'));
        $endDate   = strval(date('Y-' . $month . '-31'));
        return $this->query("SELECT COUNT(id) as result FROM tb_project WHERE id_user = $id AND progress = 'COMPLETE' AND updated_at >= '$startDate' AND updated_at < '$endDate'")->getResult()[0]->result;
    }



    // For Admin
    public function getAllProjectAdmin()
    {
        return $this->query("SELECT COUNT(id) as result FROM tb_project")->getResult()[0]->result;
    }

    public function getProgressAdmin()
    {
        return $this->query("SELECT COUNT(id) as result FROM tb_project WHERE progress = 'WORKING ON IT'")->getResult()[0]->result;
    }

    public function getCompleteAdmin()
    {
        return $this->query("SELECT COUNT(id) as result FROM tb_project WHERE progress = 'COMPLETE'")->getResult()[0]->result;
    }

    public function getProjectMonthlyAdmin($month)
    {
        $startDate = strval(date('Y-' . $month . '-01'));
        $endDate   = strval(date('Y-' . $month . '-31'));
        return $this->query("SELECT COUNT(id) as result FROM tb_project WHERE progress = 'COMPLETE' AND updated_at >= '$startDate' AND updated_at < '$endDate'")->getResult()[0]->result;
    }

    public function getListProject($limit, $sort, $divisi, $company, $id, $role)
    {

        $conditionalCompany = '';
        $conditionalDivisi  = '';
        $sortir             = '';
        $limitQuery         = '';

        if ($role == 'admin') {
            if ($company != 'Semua') {
                $conditionalCompany = "WHERE tb_user.company = '$company'";
            } else {
                $conditionalCompany = "WHERE tb_project.id != 0";
            }
            if ($divisi != 'Semua') {
                $conditionalDivisi  = "AND tb_user.division = '$divisi'";
            }
        } else {
            $conditionalCompany = "WHERE tb_project.id_user = $id";
        }

        if ($sort == 'newest') {
            $sortir = "ORDER BY tb_project.updated_at DESC";
        } else if ($sort == 'abjad') {
            $sortir = "ORDER BY tb_project.project ASC";
        } else if ($sort == 'working') {
            $sortir = "AND tb_project.progress = 'WORKING ON IT' ORDER BY tb_project.updated_at DESC";
        } else if ($sort == 'complete') {
            $sortir = "AND tb_project.progress = 'COMPLETE' ORDER BY tb_project.updated_at DESC";
        } else if ($sort == 'pending') {
            $sortir = "AND tb_project.progress = 'PENDING' ORDER BY tb_project.updated_at DESC";
        }

        if ($limit != 0) {
            $limitQuery = "LIMIT $limit";
        }



        $query = "SELECT tb_project.id, tb_project.project, tb_project.description, tb_project.progress, tb_project.due_date, tb_project.estimation_cpus, tb_project.estimation_cost, tb_project.estimation_revenue, tb_project.actual_cpus, tb_project.actual_cost, tb_project.actual_revenue, tb_project.priority, tb_project.progress, tb_project.project_type, tb_user.division, tb_user.company FROM tb_project LEFT JOIN tb_user ON tb_project.id_user = tb_user.id $conditionalCompany $conditionalDivisi $sortir $limitQuery";

        return $this->query($query)->getResult();
    }


    public function detailProject($id)
    {
        $db      = \Config\Database::connect();
        $builder = $db->table('tb_user');
        $builder->select('*');
        $builder->join('tb_project', 'tb_project.id_user = tb_user.id', 'left');
        $builder->where('tb_project.id', $id);
        $query = $builder->get()->getRowArray();
        return $query;
    }

    public function listFiles($id_project)
    {
        $db      = \Config\Database::connect();
        $builder = $db->table('tb_file');
        $builder->select('*');
        $builder->where('id_project', $id_project);
        $query = $builder->get()->getResult();
        return $query;
    }

    public function deleteFiles($id_project)
    {
        $db      = \Config\Database::connect();
        $builder = $db->table('tb_file');
        $builder->where('id_project', $id_project);
        $builder->delete();
        return $builder;
    }

    public function insertFile($file_name, $id_project)
    {
        $db      = \Config\Database::connect();
        $builder = $db->table('tb_file');
        $this->allowedFields = ['file_name', 'id_project', 'created_at', 'updated_at'];
        $this->useTimestamps = true;

        $data    = [
            'file_name'     => $file_name,
            'id_project'    => $id_project
        ];

        $insert = $builder->insert($data);
    }
}
