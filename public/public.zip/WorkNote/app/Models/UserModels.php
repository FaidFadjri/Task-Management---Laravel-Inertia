<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModels extends Model
{
    protected $table      = 'tb_user';
    protected $primaryKey = 'id';
    protected $allowedFields = ['username', 'password', 'full_name', 'division', 'gender', 'company', 'image', 'status'];
    protected $useTimestamps = false;


    public function checkUsername($username)
    {
        $db      = \Config\Database::connect();
        $builder = $db->table('tb_user');

        return $builder->getWhere(['username' => $username])->getRowArray();
    }

    public function checkPassword($username, $password)
    {
        $db      = \Config\Database::connect();
        $builder = $db->table('tb_user');

        $condition = array(
            'username' => $username,
            'password' => $password
        );

        return $builder->where($condition)->get()->getRowArray();
    }

    public function getDistinctDivision()
    {
        return $this->query("SELECT DISTINCT division FROM tb_user")->getResult();
    }

    public function getDistinctCompany()
    {
        return $this->query("SELECT DISTINCT company FROM tb_user")->getResult();
    }
}
