<?php

namespace App\Models;

use CodeIgniter\Model;

class CommentModels extends Model
{
    protected $table      = 'tb_comment';
    protected $primaryKey = 'id';

    protected $allowedFields = ['comment', 'id_user', 'id_project', 'created_at', 'updated_at'];
    protected $useTimestamps = true;

    public function getComment($id_project)
    {
        $query = "SELECT tb_comment.comment, tb_comment.id_user, tb_comment.created_at, tb_user.image, tb_user.username 
        FROM tb_comment LEFT JOIN tb_project ON tb_comment.id_project = tb_project.id LEFT JOIN tb_user ON tb_comment.id_user = tb_user.id WHERE tb_project.id = $id_project ORDER BY tb_comment.created_at ASC";
        return $this->query($query)->getResult();
    }
}
