<!-- Modal -->
<div class="modal fade" id="addModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-fullscreen-sm-down">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add Project</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="addForm" action="/project/addProject" method="POST">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-4 col-sm-12">
                            <div class="mb-2">
                                <label for="project" class="form-label">Project</label>
                                <input type="text" class="form-control" name="project" autocomplete="off" placeholder="Judul Project | Aktivitas" required>
                            </div>
                            <div class="mb-2">
                                <label for="waktu" class="form-label">Tenggang Waktu</label>
                                <input type="date" class="form-control" id="waktu" name="waktu" required>
                            </div>
                            <div class="mb-2">
                                <label class="form-label">Progress</label>
                                <select name="progress" class="form-control" name="progress">
                                    <option value="TO DO">TO DO</option>
                                    <option value="WORKING ON IT">WORKING ON IT</option>
                                    <option value="PENDING">PENDING</option>
                                    <option value="STUCK">STUCK</option>
                                    <option value="COMPLETE">COMPLETE</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-4 col-sm-12">
                            <div class="mb-2">
                                <label class="form-label">Estimasi Biaya</label>
                                <input type="number" class="form-control" name="estimasi_biaya">
                            </div>
                            <div class="mb-2">
                                <label class="form-label">Estimasi CPUs</label>
                                <input type="number" class="form-control" name="estimasi_cpus">
                            </div>
                            <div class="mb-2">
                                <label class="form-label">Estimasi Revenue</label>
                                <input type="number" class="form-control" name="estimasi_revenue">
                            </div>
                        </div>
                        <div class="col-lg-4 col-sm-12">
                            <div class="mb-2">
                                <label class="form-label">Biaya Aktual</label>
                                <input type="number" class="form-control" name="biaya_aktual">
                            </div>
                            <div class="mb-2">
                                <label class="form-label">CPUs Aktual</label>
                                <input type="number" class="form-control" name="cpus_aktual">
                            </div>
                            <div class="mb-2">
                                <label class="form-label">Revenue Aktual</label>
                                <input type="number" class="form-control" name="revenue_aktual">
                            </div>
                        </div>
                        <div class="col-lg-6 col-sm-12">
                            <div class="mt-2">
                                <select name="jenis" class="form-control" required>
                                    <option value="PROJECT">PROJECT</option>
                                    <option value="ACTIVITY">ACTIVITY</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-6 col-sm-12">
                            <div class="mt-2">
                                <select name="priority" class="form-control" required>
                                    <option value="">PRIORITY</option>
                                    <option value="low">LOW</option>
                                    <option value="medium">MEDIUM</option>
                                    <option value="high">HIGH</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                    <button type="submit" class="btn btn-primary" id="addButtonForm">Tambahkan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- detail & Edit Modal -->
<div class="modal fade" id="detailModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Detail Project</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="/project/updateproject" id="detailForm" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="container">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-6 col-sm-12">
                                    <input type="hidden" name="id_project" id="id_project" readonly>
                                    <div class="header">
                                        <input type="text" name="detailJudul" id="detailJudul" class="form-input detailJudul" placeholder="Your Project Here ..">
                                        <img src="/img/<?= $user['image']; ?>" alt="member" id="profile_image">
                                    </div>
                                    <div class="detail-desc-wrapper">
                                        <textarea name="detailDesc" id="detailDesc" class="form-input mt-2 detailDesc" placeholder="Type description Here"></textarea>

                                        <div class="mb-2 mt-2">
                                            <label class="form-label">Estimasi Biaya</label>
                                            <input type="text" class="form-input" id="detailEstimasiBiaya" placeholder="Estimasi Biaya" name="detailEstimasiBiaya" required>
                                        </div>
                                        <div class="mb-2 mt-2">
                                            <label class="form-label">Biaya Aktual</label>
                                            <input type="text" class="form-input" id="detailBiayaAktual" placeholder="Biaya Aktual" name="detailBiayaAktual" required>
                                        </div>
                                        <div class="mb-2">
                                            <label class="form-label">Estimasi CPUs</label>
                                            <input type="text" class="form-input" id="detailEstimasiCPUS" placeholder="Estimasi CPUs" name="detailEstimasiCPUS" required>
                                        </div>
                                        <div class="mb-2">
                                            <label class="form-label">Aktual CPUs</label>
                                            <input type="text" class="form-input" id="detailAktualCPUS" placeholder="Aktual CPUs" name="detailAktualCPUS" required>
                                        </div>
                                        <div class="mb-2">
                                            <label class="form-label">Estimasi Revenue</label>
                                            <input type="text" class="form-input" id="detailEstimasiRevenue" placeholder="Estimasi Revenue" name="detailEstimasiRevenue" required>
                                        </div>
                                        <div class="mb-2">
                                            <label class="form-label">Aktual Revenue</label>
                                            <input type="text" class="form-input" id="detailAktualRevenue" placeholder="Aktual Revenue" name="detailAktualRevenue" required>
                                        </div>
                                        <div class="mb-2">
                                            <label class="form-label">Progress</label>
                                            <select name="detailProgress" id="detailProgress" class="form-input">
                                                <option value="TO DO">TO DO</option>
                                                <option value="WORKING ON IT">WORKING ON IT</option>
                                                <option value="PENDING">PENDING</option>
                                                <option value="STUCK">STUCK</option>
                                                <option value="COMPLETE">COMPLETE</option>
                                            </select>
                                        </div>
                                        <div class="mb-2">
                                            <label class="form-label">Priority</label>
                                            <select name="detailPriority" id="detailPriority" class="form-input">
                                                <option value="LOW">LOW</option>
                                                <option value="MEDIUM">MEDIUM</option>
                                                <option value="HIGH">HIGH</option>
                                            </select>
                                        </div>
                                        <div class="mb-2">
                                            <label class="form-label">Input File</label>
                                            <input type="file" name="file_data" class="form-input">
                                        </div>
                                        <div class="mb-2">
                                            <label class="form-label">Due Date</label>
                                            <input type="date" name="detailWaktu" id="detailWaktu" class="form-input">
                                        </div>
                                        <div class="mb-2 mt-2" id="listFile">
                                            <!-- <button type="button" class="btnFiles" data-id="">
                                                <p>File SQL.csv</p>
                                            </button> -->
                                        </div>
                                        <br>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-sm-12">
                                    <div class="comment" id="commentList"></div>
                                    <div class="typeWrapper mt-3">
                                        <input type="text" placeholder="type something .." class="form-input" id="inputComment" autocomplete="off">
                                        <button type="button" id="sendComment">SEND</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" id="deleteBtn">DELETE</button>
                    <button type="submit" class="btn btn-primary">UPDATE</button>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- session -->
<?php $session = session(); ?>
<input type="hidden" id="usernameData" value="<?= $session->get('username'); ?>">
<input type="hidden" id="imageData" value="<?= $user['image']; ?>">

<script>
    $('#addForm').submit(function(e) {

        e.preventDefault();

        $.ajax({
            type: "POST",
            url: "/project/addProject",
            data: $("#addForm").serialize(),
            dataType: "json",
            async: false,
            success: function(response) {
                Swal.fire({
                    position: 'center',
                    icon: 'success',
                    title: 'Your work has been saved',
                    showConfirmButton: false,
                    timer: 1500
                }).then(function() {
                    window.location = "/project/projectMenu";
                });
            }
        });
    })

    $('#detailForm').submit(function(e) {
        e.preventDefault();

        var form = $("#detailForm");
        var formData = new FormData(form[0]);

        $.ajax({
            type: "POST",
            url: $('#detailForm').attr('action'),
            data: formData,
            async: false,
            enctype: 'multipart/form-data',
            cache: false,
            contentType: false,
            processData: false,
            success: function(response) {
                Swal.fire({
                    position: 'center',
                    icon: 'success',
                    title: 'Your work has been saved',
                    showConfirmButton: false,
                    timer: 1500
                }).then(function() {
                    window.location = "/project/projectMenu";
                });
            },
            beforeSend: function(e) {
                Swal.showLoading();
            }
        });
    });

    $('#deleteBtn').on('click', function() {

        let id = $('#id_project').val();

        Swal.fire({
            title: 'Do you want to Delete project ?',
            showDenyButton: false,
            showCancelButton: true,
            confirmButtonText: 'Delete',
        }).then((result) => {
            /* Read more about isConfirmed, isDenied below */
            if (result.isConfirmed) {
                Swal.fire('Saved!', '', 'success');
                $.ajax({
                    type: "POST",
                    url: "/project/deleteProject",
                    data: {
                        id: id
                    },
                    async: false,
                    dataType: "json",
                    success: function(response) {
                        Swal.fire({
                            position: 'center',
                            icon: 'success',
                            title: 'Delete Successful',
                            showConfirmButton: false,
                            timer: 1000
                        }).then(function() {
                            window.location = "/project/projectMenu";
                        });
                    },
                    beforeSend: function(e) {
                        Swal.showLoading();
                    }
                });
            }
        })


    });

    $('#sendComment').on('click', function() {
        let input = $('#inputComment').val();
        let id_project = $('#id_project').val();
        let username = $('#usernameData').val();
        let image = $('#imageData').val();

        if (input != "") {
            $.ajax({
                type: "POST",
                url: "/project/sendComment",
                data: {
                    input: input,
                    id_project: id_project
                },
                async: false,
                dataType: "json",
                success: function(response) {
                    let comment = '';
                    comment += '<div class="chat-right">';
                    comment += '<div class="chat">';
                    comment += '<div class="pesan">';
                    comment += input + '<br> - ';
                    comment += username;
                    comment += '</div>';
                    comment += '<img src="/img/' + image + '" alt="profile">';
                    comment += '</div>';
                    comment += '</div>';
                    $('#commentList').append(comment);
                },
                complete: function() {
                    $('#inputComment').val("");
                }
            });
        } else {
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: 'Kolom Chat Masih Kosong',
            })
        }
    });
</script>