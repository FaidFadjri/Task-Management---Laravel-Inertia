<button class="hamburger" id="showButton">
    <img src="/img/hamburger.svg" alt="">
</button>

<?php
$session = session();
?>

<div class="sidebar d-none">
    <button class="close" id="closeButton">
        <img src="/img/ic_close.png" alt="">
    </button>
    <br>
    <div class="title">
        <p>Work <span class="strong">Note</span></p>
    </div>
    <br>
    <hr>
    <div class="menu">
        <a href="/project/home" class="sidebar-item <?= $active == 'dashboard' ? 'sidebar-active' : ''; ?>">
            <i class="fas fa-chart-line"></i>
            Dashboard
        </a>
    </div>
    <div class="menu">
        <a href="/project/projectMenu" class="sidebar-item <?= $active == 'project' ? 'sidebar-active' : ''; ?>">
            <i class="fas fa-tasks"></i>
            Project
        </a>
    </div>

    <?php if ($session->get('role') == 'admin') : ?>
        <div class="menu">
            <a href="/project/member" class="sidebar-item <?= $active == 'member' ? 'sidebar-active' : ''; ?>">
                <i class="fas fa-users"></i>
                Member
            </a>
        </div>
    <?php endif; ?>

    <a href="/logout" class="logout_button" style="text-decoration: none;">
        <i class="fas fa-sign-out-alt"></i>
        Logout
    </a>
</div>