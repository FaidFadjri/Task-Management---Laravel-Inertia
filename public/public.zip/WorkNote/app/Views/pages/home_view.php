<?= $this->extend('templates/project_index'); ?>

<?= $this->section('content'); ?>
<script src="/js/grafik.js"></script>

<?php
$session = session();
?>

<input type="hidden" id="user_id" value="<?= $session->get('id'); ?>">

<section>
    <br>
    <div class="main-area">

        <?= $this->include('templates/banner'); ?>

        <div class="progress-area mt-3">
            <div class="progress-wrap" title="Progress Pekerjaan Anda">
                <p><?= substr(strval($percentage), 0, 1) . '%'; ?></p>
                <p>Task Progress</p>
                <div class="progress">
                    <div class="progress-bar progress-bar-striped bg-info" role="progressbar" style="width: <?= $percentage . '%'; ?>" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
            </div>
            <div class="total-project running-project">
                <img src="/img/ic-progress.png" alt="icon">
                <div class="text">
                    <?php if ($progress < 10) : ?>
                        <p><?= $progress; ?> Progress Projects</p>
                    <?php endif; ?>
                    <?php if ($progress >= 10) : ?>
                        <p>10+ Progress Projects</p>
                    <?php endif; ?>
                    <span></span>
                </div>
            </div>
            <div class="total-project complete-project">
                <img src="/img/ic-complete.png" alt="icon">
                <div class="text">
                    <?php if ($complete < 10) : ?>
                        <p><?= $complete; ?> Complete Projects</p>
                    <?php endif; ?>
                    <?php if ($complete >= 10) : ?>
                        <p>10+ Complete Projects</p>
                    <?php endif; ?>
                    <span></span>
                </div>
            </div>
        </div>

        <div class="grafik-area">
            <canvas id="myChart" width="400" height="80"></canvas>
        </div>

    </div>
</section>

<script>
    grafik();
</script>
<?= $this->endSection(); ?>