<?php $session = session(); ?>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.12/cropper.min.js" integrity="sha512-ooSWpxJsiXe6t4+PPjCgYmVfr1NS5QXJACcR/FPpsdm6kqG1FmQ2SVyg2RXeVuCRBLr0lWHnWJP6Zs1Efvxzww==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.12/cropper.min.css" integrity="sha512-0SPWAwpC/17yYyZ/4HSllgaK7/gg9OlVozq8K7rf3J8LvCjYEEIfzzpnA2/SSjpGIunCSD18r3UhvDcu/xncWA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<div class="banner-welcome">
    <div class="banner-text">
        <?php if ($session) : ?>
            <?php if ($session->get('gender') == 'PRIA') : ?>
                <p class="banner-title">Welcome Mr <?= $session->get('full_name'); ?></p>
            <?php endif; ?>
            <?php if ($session->get('gender') == 'WANITA') : ?>
                <p class="banner-title">Welcome Ms <?= $session->get('full_name'); ?></p>
            <?php endif; ?>
        <?php endif; ?>
        <?php if ($session->get('role') == 'member') : ?>
            <p class="banner-desc">You have <?= $progress; ?> Task On Progress Today</p>
        <?php endif; ?>
        <div class="star">
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
            <i class="fas fa-star"></i>
        </div>
        <div class="btnArea mt-3">
            <button class="editProfile">Edit Profiles</button>
        </div>
    </div>
    <div class="profile-wrapper">
        <img src="/img/<?= $user['image']; ?>" alt="profile" class="profile">
        <input type="file" class="changeImage">
    </div>
</div>


<!-- Modal -->
<div class="modal fade" id="cropModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Crop Image</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="img-container">
                    <div class="row">
                        <div class="col-6">
                            <img id="image" class="imgCrop">
                        </div>
                        <div class="col-6">
                            <div class="preview"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary" id="crop">Crop</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->

<!-- Modal -->
<div class="modal fade" id="editProfilModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Edit Profile</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="detailUserForm">
                <div class="modal-body">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12">
                                <div class="mb-2">
                                    <label for="username" class="form-label">Username</label>
                                    <input type="text" name="username" id="username" class="form-control" autocomplete="off" required>
                                </div>
                                <div class="mb-2">
                                    <label for="password" class="form-label">Password</label>
                                    <input type="text" name="password" id="password" class="form-control" autocomplete="off" required>
                                </div>
                                <div class="mb-2">
                                    <label for="full_name" class="form-label">Full Name</label>
                                    <input type="full_name" name="full_name" id="full_name" class="form-control" autocomplete="off" required>
                                </div>
                                <div class="mb-2">
                                    <label for="division" class="form-label">Division</label>
                                    <select name="division" id="division" class="form-control" required>
                                        <option value="Body Paint">Body Paint</option>
                                        <option value="General Repair">General Repair</option>
                                        <option value="Business Development">Business Development</option>
                                        <option value="Finance">Finance</option>
                                        <option value="Finance - HCD">Finance - HCD</option>
                                        <option value="HCD">HCD</option>
                                    </select>
                                </div>
                                <div class="mb-2">
                                    <label for="gender" class="form-label">Gender</label>
                                    <select name="gender" id="gender" class="form-control" required>
                                        <option value="PRIA">PRIA</option>
                                        <option value="WANITA">WANITA</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Edit</button>
                </div>
                <input type="hidden" name="id_member" id="id_user" value="<?= $session->get('id'); ?>">
            </form>
        </div>
    </div>
</div>

<script>
    $('.editProfile').on('click', function() {
        $('#editProfilModal').modal('show');
        let id = $('#id_user').val();
        $.ajax({
            type: "POST",
            url: "/project/detailMember",
            data: {
                id: id
            },
            async: false,
            dataType: "json",
            success: function(response) {
                const user = response.user;
                $('#detailUserForm #id_user').val(user.id);
                $('#detailUserForm #username').val(user.username);
                $('#detailUserForm #password').val(user.password);
                $('#detailUserForm #full_name').val(user.full_name);
                $('#detailUserForm #division').val(user.division).change();
                $('#detailUserForm #gender').val(user.gender).change();
            }
        });
    });

    $('#detailUserForm').submit(function(e) {
        e.preventDefault();
        $.ajax({
            type: "POST",
            url: "/project/updateUser",
            data: $(this).serialize(),
            async: false,
            dataType: "json",
            success: function(response) {
                if (response.status == 200) {
                    Swal.fire({
                        position: 'top-end',
                        icon: 'success',
                        title: 'Changes saved!',
                        showConfirmButton: false,
                        timer: 1500
                    }).then(function() {
                        window.location = "";
                    })
                }
            }
        });
    });
</script>

<script>
    $('.changeImage').hover(function() {
        $('.profile').css("opacity", "0.5");
    });

    $('.changeImage').mouseleave(function() {
        $('.profile').css("opacity", "1");
    });


    var bs_modal = $('#cropModal');
    var image = document.getElementById('image');
    var cropper, reader, file;

    $('.changeImage').change(function(e) {
        // get Files
        var files = e.target.files;
        // show modal
        var done = function(url) {
            image.src = url;
            bs_modal.modal('show');
        };


        // jika ada files
        if (files && files.length > 0) {
            file = files[0];
            if (URL) {
                done(URL.createObjectURL(file));
            } else if (FileReader) {
                reader = new FileReader();
                reader.onload = function(e) {
                    done(reader.result);
                };
                reader.readAsDataURL(file);
            }
        }
    });

    bs_modal.on('shown.bs.modal', function() {
        cropper = new Cropper(image, {
            aspectRatio: 1,
            viewMode: 3,
            preview: '.preview'
        });
    }).on('hidden.bs.modal', function() {
        cropper.destroy();
        cropper = null;
    });

    $("#crop").click(function() {
        canvas = cropper.getCroppedCanvas({
            width: 160,
            height: 160,
        });

        canvas.toBlob(function(blob) {
            url = URL.createObjectURL(blob);
            var reader = new FileReader();
            reader.readAsDataURL(blob);
            reader.onloadend = function() {
                var base64data = reader.result;

                $.ajax({
                    type: "POST",
                    dataType: "json",
                    url: "/project/save_image",
                    data: {
                        image: base64data
                    },
                    success: function(data) {},
                    complete: function() {
                        bs_modal.modal('hide');
                        Swal.fire({
                            position: 'center',
                            icon: 'success',
                            title: 'Your work has been saved',
                            showConfirmButton: false,
                            timer: 1500
                        });
                        window.location = "";
                    },
                    fail: function() {
                        Swal.fire({
                            icon: 'error',
                            title: 'Oops...',
                            text: 'Your Connection is broken!',
                        })
                    }
                });
            };
        });
    });
</script>