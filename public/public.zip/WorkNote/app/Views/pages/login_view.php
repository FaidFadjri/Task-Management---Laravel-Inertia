<?= $this->extend('templates/login_index'); ?>

<?= $this->section('content'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="/js/login.js"></script>


<section>
  <div class="main">
    <div class="left-area">
      <div class="title-area">
        <img src="/img/team.png" alt="vector team">
        <div class="title-text">
          <p class="title-head">Work <span class="strong">Note</span></p>
          <p class="title-description">Manage Your Team Better.</p>
          <p class="title-description">Then Be a Great Leader</p>
        </div>
      </div>
      <svg class="left-wave" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
        <path fill="#f0f2f5" fill-opacity="1" d="M0,160L24,160C48,160,96,160,144,144C192,128,240,96,288,85.3C336,75,384,85,432,112C480,139,528,181,576,213.3C624,245,672,267,720,277.3C768,288,816,288,864,266.7C912,245,960,203,1008,170.7C1056,139,1104,117,1152,133.3C1200,149,1248,203,1296,213.3C1344,224,1392,192,1416,176L1440,160L1440,320L1416,320C1392,320,1344,320,1296,320C1248,320,1200,320,1152,320C1104,320,1056,320,1008,320C960,320,912,320,864,320C816,320,768,320,720,320C672,320,624,320,576,320C528,320,480,320,432,320C384,320,336,320,288,320C240,320,192,320,144,320C96,320,48,320,24,320L0,320Z"></path>
      </svg>
    </div>
    <div class="right-area">
      <form class="form">
        <lottie-player class="people-lottie" src="https://assets4.lottiefiles.com/packages/lf20_jvt4bdg7.json" background="transparent" speed="1" loop autoplay></lottie-player>
        <input type="text" class="form_input" placeholder="username" id="username" autocomplete="off">
        <input type="password" class="form_input" placeholder="password" id="password" autocomplete="off">
        <button class="form_button" type="button" id="login_button">Login</button>
        <div class="copyright">
          <p>@copyright by Mohamad Faid Fadjri</p>
        </div>
      </form>
    </div>
  </div>
</section>

<script>
  runApp();
</script>
<?= $this->endSection(); ?>