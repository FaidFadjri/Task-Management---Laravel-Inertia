<?= $this->extend('templates/project_index'); ?>

<?= $this->section('content'); ?>
<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script src="/js/member.js"></script>
<link rel="stylesheet" href="/css/member.css">
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<section>
    <div class="container">
        <div class="row">
            <div class="col-12 mt-5">
                <h3 class="title-member">Daftar Member</h3>
            </div>
            <div class="col-12">
                <button class="addBtn float-end"><i class="fas fa-plus"></i> Tambah Member</button>
            </div>
        </div>
        <div class="row justify-content-center mt-5">
            <div class="col-lg-12">
                <div class="userList">
                    <div class="user">
                        <div class="user-text">
                            <p class="user-name">Mohamad Faid Fadjri</p>
                            <p class="user-division">Business Development</p>
                            <div class="button-area">
                                <button class="btn btn-success">EDIT</button>
                                <button class="btn btn-danger">DELETE</button>
                            </div>
                        </div>
                        <div class="user-img-area">
                            <img src="/img/default-image.png" alt="profile-img" class="user-img">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


<!-- Modal -->
<div class="modal fade" id="addMemberModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Change Member</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="/project/addMember" id="addForm">
                <div class="modal-body">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <div class="mb-2">
                                    <label for="username" class="form-label">Username</label>
                                    <input type="text" name="username" id="username" class="form-control" autocomplete="off" required>
                                </div>
                                <div class="mb-2">
                                    <label for="password" class="form-label">Password</label>
                                    <input type="text" name="password" id="password" class="form-control" autocomplete="off" required>
                                </div>
                                <div class="mb-2">
                                    <label for="full_name" class="form-label">Full Name</label>
                                    <input type="full_name" name="full_name" id="full_name" class="form-control" autocomplete="off" required>
                                </div>
                                <div class="mb-2">
                                    <label for="division" class="form-label">Division</label>
                                    <select name="division" id="division" class="form-control" required>
                                        <option value="Body Paint">Body Paint</option>
                                        <option value="General Repair">General Repair</option>
                                        <option value="Business Development">Business Development</option>
                                        <option value="Business Development">Sparepart</option>
                                        <option value="Finance">Finance</option>
                                        <option value="Finance - HCD">Finance - HCD</option>
                                        <option value="HCD">HCD</option>
                                        <option value="KSC - Palima">PALIMA</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <div class="mb-2">
                                    <label for="gender" class="form-label">Gender</label>
                                    <select name="gender" id="gender" class="form-control" required>
                                        <option value="PRIA">PRIA</option>
                                        <option value="WANITA">WANITA</option>
                                    </select>
                                </div>
                                <div class="mb-2">
                                    <label for="company" class="form-label">Company</label>
                                    <select name="company" id="company" class="form-control" required>
                                        <option value="AKASTRA">AKASTRA</option>
                                        <option value="KSC-PANDEGLANG">KSC - PANDEGLANG</option>
                                        <option value="KSC-PALIMA">KSC - PALIMA</option>
                                    </select>
                                </div>
                                <div class="mb-2">
                                    <label for="status" class="form-label">Status</label>
                                    <select name="status" id="status" class="form-control" required>
                                        <option value="admin">ADMIN</option>
                                        <option value="member">MEMBER</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Update</button>
                </div>
                <input type="hidden" name="id_member" id="id_user" value="-">
            </form>
        </div>
    </div>
</div>

<script>
    $('#addForm').submit(function(e) {
        e.preventDefault();
        $.ajax({
            type: "POST",
            url: $(this).attr('action'),
            data: $(this).serialize(),
            async: false,
            dataType: 'json',
            success: function(response) {
                Swal.fire({
                    position: 'center',
                    icon: 'success',
                    title: 'Member Changes, Saved!',
                    showConfirmButton: false,
                    timer: 1500
                }).then(function() {
                    window.location = "/project/member";
                });
            }
        });
    });
    getMember();
</script>

<?= $this->endSection(); ?>