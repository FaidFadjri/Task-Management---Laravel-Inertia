<?= $this->extend('templates/project_index'); ?>


<?= $this->section('content'); ?>

<?php
$session = session();
?>

<link rel="stylesheet" href="/css/sidebar.css">
<link rel="stylesheet" href="/css/profile.css">
<link rel="stylesheet" href="/css/project.css">
<link rel="icon" type="image/png" href="/img/favicon.png">
<link rel="stylesheet" href="/css/modal.css">
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<section>
    <br>
    <div class="main-area">

        <?= $this->include('templates/banner'); ?>

        <div class="button-area">
            <div class="select">
                <select id="selectProject" class="form-control selectProject">
                    <option value="5">5</option>
                    <option value="10">10</option>
                    <option value="0">All</option>
                </select>
                <select id="selectSortir" class="form-control selectSortir">
                    <option value="newest">Paling Terbaru</option>
                    <option value="abjad">Berdasarkan Abjad</option>
                    <option value="pending">Pending</option>
                    <option value="working">Working</option>
                    <option value="complete">Complete</option>
                </select>
                <?php if ($session->get('role') == 'admin') : ?>
                    <select id="selectDivision" class="form-control selectDivision">
                        <option value="Semua">All Division</option>
                        <?php foreach ($divisi as $row) : ?>
                            <option value="<?= $row->division; ?>"><?= $row->division; ?></option>
                        <?php endforeach; ?>
                    </select>
                    <select id="selectCompany" class="form-control selectCompany">
                        <option value="Semua">All Company</option>
                        <?php foreach ($company as $row) : ?>
                            <option value="<?= $row->company; ?>"><?= $row->company; ?></option>
                        <?php endforeach; ?>
                    </select>
                <?php endif; ?>
            </div>
            <button class="addButton" id="addButton"><i class="fas fa-plus-square"></i> Add Project</button>
        </div>

        <div class="list-project" id="ProjectList">
        </div>
    </div>
</section>
<br>


<?= $this->include('templates/modal'); ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />
<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.6.2/chart.min.js" integrity="sha512-tMabqarPtykgDtdtSqCL3uLVM0gS1ZkUAVhRFu1vSEFgvB73niFQWJuvviDyBGBH22Lcau4rHB5p2K2T0Xvr6Q==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="/js/project.js"></script>


<script>
    getProject(5);
    project();
</script>
<?= $this->endSection(); ?>