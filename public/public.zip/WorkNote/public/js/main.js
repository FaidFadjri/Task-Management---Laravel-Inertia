function runApp() {
    $('#showButton').click(function() {
        $('.sidebar').removeClass('hide-sidebar');
        $('.sidebar').removeClass('d-none');
        $('.sidebar').addClass('show-sidebar');
        $('.sidebar').addClass('sidebar-showed');
        
    });

    $('#closeButton').click(function () { 
        $('.sidebar').removeClass('show-sidebar');
        $('.sidebar').addClass('hide-sidebar');
        setTimeout(function() {
            $('.sidebar').addClass('d-none');
        }, 200);
     })
}