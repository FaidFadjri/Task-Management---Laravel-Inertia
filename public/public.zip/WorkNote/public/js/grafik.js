function grafik() { 
    $.ajax({
        type: "POST",
        url: "/project/getGrafik",
        dataType: "json",
        async : false,
        success: function (response) {
            runGrafik(response.grafik);
        }
    });
}


function runGrafik(grafik) { 
    const ctx = document.getElementById('myChart');
    const myChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'Oktober', 'November', 'Desember'],
        datasets: [{
            label: 'Complete Project',
            data: grafik,
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: 'rgb(75, 192, 192)',
            borderWidth: 2,
        }]
    },
    options: {
        scales: {
            y: {
                beginAtZero: true
            }
        },
        animations: {
            tension: {
                duration: 1500,
                easing: 'easeInCirc',
                from: 1,
                to: 0,
                loop: false
            }
        },
    }
});


 }