function editProfile() {
    var image = document.getElementById('image');
    var cropper, reader, file;

    $('.changeImage').change(function(e) {
        // get Files
        var files = e.target.files;
        // show modal
        var done = function(url) {
            image.src = url;
            $('#cropModal').modal('show');
        };


        // jika ada files
        if (files && files.length > 0) {
            file = files[0];
            if (URL) {
                done(URL.createObjectURL(file));
            } else if (FileReader) {
                reader = new FileReader();
                reader.onload = function(e) {
                    done(reader.result);
                };
                reader.readAsDataURL(file);
            }
        }
    });

    $('#cropModal').on('shown.bs.modal', function() {
        cropper = new Cropper(image, {
            aspectRatio: 1,
            viewMode: 3,
            preview: '.preview'
        });
    }).on('hidden.bs.modal', function() {
        cropper.destroy();
        cropper = null;
    });

    $("#crop").click(function() {
        canvas = cropper.getCroppedCanvas({
            width: 160,
            height: 160,
        });

        canvas.toBlob(function(blob) {
            url = URL.createObjectURL(blob);
            var reader = new FileReader();
            reader.readAsDataURL(blob);
            reader.onloadend = function() {
                var base64data = reader.result;

                $.ajax({
                    type: "POST",
                    dataType: "json",
                    url: "/project/save_image",
                    data: {
                        image: base64data
                    },
                    success: function(data) {},
                    complete: function() {
                        $('#cropModal').modal('hide');
                        Swal.fire({
                            position: 'center',
                            icon: 'success',
                            title: 'Your work has been saved',
                            showConfirmButton: false,
                            timer: 1500
                        });
                        window.location = "";
                    },
                    fail: function() {
                        Swal.fire({
                            icon: 'error',
                            title: 'Oops...',
                            text: 'Your Connection is broken!',
                        })
                    }
                });
            };
        });
    });
 }