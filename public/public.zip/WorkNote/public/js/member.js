function getMember() { 
    let userList = $('.userList');

    // get member
    $.ajax({
        type        : "POST",
        url         : "/project/getMember",
        async       : false,
        dataType    : "json",
        success: function (response) {
            const user   = response.user;
            let htmlUser = '';
            for (let index = 0; index < user.length; index++) {
                htmlUser += '<div class="user">';
                htmlUser += '<div class="user-text">';
                htmlUser += '<p class="user-name">' + user[index].full_name + '</p>';
                htmlUser += '<p class="user-division">' + user[index].division + '</p>';
                htmlUser += '<div class="button-area">';
                htmlUser += '<button class="btn btn-success editBtn" data-id="' + user[index].id + '">Edit</button>';
                htmlUser += '<button class="btn btn-danger deleteBtn" data-id="' + user[index].id + '">Delete</button>';
                htmlUser += '</div>';
                htmlUser += '</div>';
                htmlUser += '<div class="user-img-area">';
                htmlUser += '<img src="/img/' + user[index].image + '" alt="profile-img" class="user-img">';
                htmlUser += '</div>';
                htmlUser += '</div>';
            } 

            userList.html(htmlUser);
        }, beforeSend: function () { 
        }, complete: function () { 
             Swal.close();
             buttonClickFunction();
          }
    });
 }


 function buttonClickFunction() { 
    $('.addBtn').on('click', function () {
        $('#addMemberModal').modal('show');
        $('#addForm')[0].reset();
    });

    $('.editBtn').on('click', function () {
        let id = $(this).attr('data-id');
        $('#addMemberModal').modal('show');
        $.ajax({
            type: "POST",
            url: "/project/detailMember",
            data: {
                id : id
            },
            async:false,
            dataType: "json",
            success: function (response) {
                const user = response.user;
                $('#addForm #id_user').val(user.id);
                $('#addForm #username').val(user.username);
                $('#addForm #password').val(user.password);
                $('#addForm #full_name').val(user.full_name);
                $('#addForm #division').val(user.division).change();
                $('#addForm #gender').val(user.gender).change();
                $('#addForm #company').val(user.company).change();
                $('#addForm #status').val(user.status).change();
            }
        });
    });

    $('.deleteBtn').on('click', function () {
        let id = $(this).attr('data-id');

        Swal.fire({
            title: 'Yakin Hapus Member Ini ?',
            showCancelButton: true,
            confirmButtonText: 'Delete',
          }).then((result) => {
            if (result.isConfirmed) {
              $.ajax({
                  type: "POST",
                  url: "/project/deleteMember",
                  data: {
                      id : id
                  },
                  async:false,
                  dataType: "json",
                  success: function (response) {
                    if(response.status == 200)
                    {
                        Swal.fire({
                            position: 'center',
                            icon: 'success',
                            title: 'Member Deleted, Congrats!',
                            showConfirmButton: false,
                            timer: 1500
                        }).then(function() {
                            window.location = "/project/member";
                        });
                    } else {
                        Swal.fire({
                            position: 'center',
                            icon: 'error',
                            title: 'Anda tidak bisa menghapus akun anda sendiri',
                            showConfirmButton: false,
                            timer: 1500
                        });
                    }
                  }
              });
            }
          })
    });
  }