function project() {
    $('#addButton').on('click', function() {
        $('#addForm')[0].reset();
        $('#addModal').modal('show');
    })
    $('#selectProject').on('change', function () { 
        let limit    = $('#selectProject').val();
        getProject(parseInt(limit));
    });

    $('#selectSortir').on('change', function () { 
        let limit    = $('#selectProject').val();
        getProject(parseInt(limit));
    });

    $('#selectDivision').on('change', function () { 
        let limit    = $('#selectProject').val();
        getProject(parseInt(limit));
    });

    $('#selectCompany').on('change', function () { 
        let limit    = $('#selectProject').val();
        getProject(parseInt(limit));
    });

    $('.detailButton').on('click', function () { 
        $('#detailModal').modal('show');
     })


    
}

function getProject(limit) {

    let sortir = $('#selectSortir').val();
    let division = $('#selectDivision').val();
    let company = $('#selectCompany').val();

    if(company === undefined)
    {
        company = 0;
    }
    
    if (division === undefined) {
        division = 0;
    }

    $.ajax({
        type: "POST",
        url: "/project/getListProject",
        data: {
            limit  : limit,
            sort   : sortir,
            divisi : division,
            company : company
        },
        dataType: "json",
        async : false,
        success: function (response) {

            const listProject = response.project;
            let html = '';
            for (let index = 0; index < listProject.length; index++) {
                html += '<div class="project">';
                html += '<div class="status-area">';
                html += '<div class="status ';
                if(listProject[index].progress == 'TO DO' || listProject[index].progress == 'PENDING' || listProject[index].progress == 'STUCK')
                {
                    html += 'todo';
                } else if(listProject[index].progress == 'WORKING ON IT')
                {
                    html += 'working';
                } else {
                    html += 'complete';
                }
                html += '">';
                html += listProject[index].progress;
                html += '</div>';
                html += '<div class="priority ';
                html += String(listProject[index].priority).toLowerCase();
                html += '">';
                html += listProject[index].priority;
                html += '</div>';
                html += '</div>';
                html += '<div class="project-title">';
                html += '<p>' + listProject[index].project + '</p>';
                html += '<div class="detail">';
                html += '<div class="input-group">';
                html += '<label for="estimation">Estimasi Biaya</label>';
                html += '<input type="text" value="' + formatRupiah(listProject[index].estimation_cost) + '" readonly>';
                html += '</div>';
                html += '<button id="' + listProject[index].id + '" class="detailButton">Detail</button>';
                html += '</div>';
                html += '</div>';
                html += '</div>';
            }

            $('#ProjectList').html(html);
        },
        beforeSend: function () { 
            Swal.showLoading();
        },
        complete: function () { 
            Swal.close();
            $('.detailButton').on('click', function () { 
                $('#detailForm')[0].reset();
                $('#detailModal').modal('show');

                let id = $(this).attr('id');
                $.ajax({
                    type: "POST",
                    url: "/project/getDetailProject",
                    data: {
                        id : id
                    },
                    dataType: "json",
                    success: function (response) {
                        $('#detailForm #detailJudul').val(response.data['project']);
                        $('#detailForm #detailDesc').val(response.data['description']);
                        $('#detailForm #detailEstimasiBiaya').val(formatRupiah(response.data['estimation_cost']));
                        $('#detailForm #detailBiayaAktual').val(formatRupiah(response.data['actual_cost']));
                        $('#detailForm #detailEstimasiCPUS').val(response.data['estimation_cpus']);
                        $('#detailForm #detailAktualCPUS').val(response.data['actual_cpus']);
                        $('#detailForm #detailEstimasiRevenue').val(formatRupiah(response.data['estimation_revenue']));
                        $('#detailForm #detailAktualRevenue').val(response.data['actual_revenue']);
                        $('#detailForm #detailWaktu').val(response.data['due_date']);
                        $('#detailForm #id_project').val(response.data['id']);
                        $('#profile_image').attr('src', '/img/' + String(response.data['image']));

                        let priority = response.data['priority'];
                        let progress = response.data['progress'];

                        if(priority == "LOW")
                        {
                            document.getElementById('detailPriority').getElementsByTagName('option')[0].selected = 'selected';
                        } else if (priority == "MEDIUM")
                        {
                            document.getElementById('detailPriority').getElementsByTagName('option')[1].selected = 'selected';
                        } else {
                            document.getElementById('detailPriority').getElementsByTagName('option')[2].selected = 'selected';
                        }

                        if(progress == "TO DO")
                        {
                            document.getElementById('detailProgress').getElementsByTagName('option')[0].selected = 'selected';
                        } else if (progress == "WORKING ON IT")
                        {
                             document.getElementById('detailProgress').getElementsByTagName('option')[1].selected = 'selected';
                        } else if (progress == "PENDING")
                        {
                            document.getElementById('detailProgress').getElementsByTagName('option')[2].selected = 'selected';
                        } else if (progress == "STUCK")
                        {
                            document.getElementById('detailProgress').getElementsByTagName('option')[3].selected = 'selected';
                        } else {
                            document.getElementById('detailProgress').getElementsByTagName('option')[4].selected = 'selected';
                        }

                        const commentData = response.comment;
                        let comment = ''
                        for (let index = 0; index < commentData.length; index++) {
                            if(commentData[index].id_user != response.user_id)
                            {
                                comment += '<div class="chat-left">';
                            } else {
                                comment += '<div class="chat-right">';
                            }
                            comment += '<div class="chat">';
                            comment += '<div class="pesan">';
                            comment += commentData[index].comment + '<br> - ';
                            comment += commentData[index].username
                            comment += '</div>';
                            comment += '<img src="/img/' + commentData[index].image + '" alt="profile">';
                            comment += '</div>';
                            comment += '</div>';
                        }

                        $('#commentList').html(comment);


                        let filesHtml  = '';
                        const fileData = response.list_file; 
                        for (let fileIndex = 0; fileIndex < fileData.length; fileIndex++) {
                            filesHtml  += '<button type="button" class="btnFiles mt-2" data-name="' + fileData[fileIndex].file_name + '">';
                            filesHtml  += '<p>' + fileData[fileIndex].file_name + '</p>';
                            filesHtml  += '</button>';
                        }

                        $('#listFile').html(filesHtml);
                        downloadFile(id);

                    }, beforeSend: function() {
                        Swal.fire({
                            title: 'Waiting ...',
                            didOpen: () => {
                              Swal.showLoading()
                            }
                          });
                    }, complete: function() {
                        Swal.close()
                    }
                });
             })
         }   
    });
 }


function downloadFile(id) { 
    $('.btnFiles').on('click', function () {
        let file_name   = $(this).attr('data-name');
        window.location = "/files/" + id + "/" + file_name;
    });
 }


 function formatRupiah(angka, prefix){
    var number_string = angka.replace(/[^,\d]/g, '').toString(),
    split   		= number_string.split(','),
    sisa     		= split[0].length % 3,
    rupiah     		= split[0].substr(0, sisa),
    ribuan     		= split[0].substr(sisa).match(/\d{3}/gi);

    // tambahkan titik jika yang di input sudah menjadi angka ribuan
    if(ribuan){
        separator = sisa ? '.' : '';
        rupiah += separator + ribuan.join('.');
    }

    rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
    return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
}