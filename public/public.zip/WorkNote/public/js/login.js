function runApp() {
    $('#login_button').on('click', function() {
        // get login value
        let username = $('#username').val();
        let password = $('#password').val();

        
       
        // checkloginValue
        $.ajax({
            type: "POST",
            url: "/project/check_login",
            data: {
                username : username,
                password : password
            },
            async : false,
            dataType: "json",
            success: function (response) {
                if(response.status == 200)
                {
                    Swal.fire({
                        position: 'top-end',
                        icon: 'success',
                        title: 'Your session has been saved',
                        showConfirmButton: true,
                        timer: 2000,
                    }).then(function() {
                        window.location = "/project/home";
                    });
                } else if (response.status == 402)
                {
                    Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: 'Your password is wrong!',
                    })
                } else {
                    Swal.fire(
                        'Sorry',
                        'Username is not exist!',
                        'question'
                    )
                }
            }
        });
    });
}